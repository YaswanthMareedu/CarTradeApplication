const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const storySchema = new Schema({
    brand: { type: String, required: [true, 'brand is required'] },
    author: {type: Schema.Types.ObjectId, ref:'User'},
    model: { type: String, required: [true, 'model is required'] },
    licenseplate: { type: String, required: [true, 'licenseplate is required'] },
    state: { type: String, required: [true, 'state is required'] },
    zipcode: { type: String, required: [true, 'zipcode is required'] },
    image_name:{type: String},
    texta: { type: String, required: [true, 'content is required'], 
             minLength: [10, 'the content should have atleast 10 characters'] },
    Status: { type: String },
    offerName: { type: String },
    Saved: { type: Boolean },
    Offered: { type: Boolean },
},
    { timestamps: true }
);

module.exports = mongoose.model('Story', storySchema);
/*
const trades = [{
    id: '1',
    brand: 'KIA',
    model: 'K5',
    licenseplate: 'TX 5436',
    image_name: '/images/kia-k5.jpg',
    state: 'Texas',
    zipcode: '75083',
    texta: 'The Kia K5, formerly known as the Kia Optima, is a mid-size car manufactured by Kia since 2000 and marketed globally through various nameplates. First generation cars were mostly marketed as the Optima, although the Kia Magentis name was used in Europe and Canada when sales began there in 2002.',
    createdAt: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
},
{
    id: '2',
    brand: 'KIA',
    model: 'SELTOS',
    licenseplate: 'NC 0239',
    image_name: '/images/kia-Seltos.jpg',
    state: 'North Carolina',
    zipcode: '28266',
    texta: "The Kia Seltos is a subcompact crossover SUV manufactured by Kia. Introduced in mid-2019, the Seltos is positioned between the smaller Stonic, Soul, or Sonet and the larger Sportage in Kia's global SUV lineup.The Seltos is designated as a global product with three variations introduced for different markets. The first variation is the largest version of the Seltos, which is manufactured in South Korea (codename: SP2) mainly aimed for developed markets, including North America and Australasia.",
    createdAt: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
},
{
    id: '3',
    brand: 'KIA',
    model: 'Stinger',
    licenseplate: 'FL 8758',
    image_name: '/images/kia-Stinger.jpg',
    state: 'Florida',
    zipcode: '33680',
    texta: "The Stinger uses a shortened version of the Hyundai Genesis' front-engine, rear-wheel-drive platform with additional steel reinforcement and is offered with a choice of two engines: a 2.0-liter turbocharged four-cylinder that produces 188 kW (255 PS; 252 hp); and a 3,342 cc (3.3 L; 203.9 cu in) twin-turbo V6 engine that generates 272 kW (370 PS; 365 hp) at 6,000 rpm and 510 N⋅m (376 lbf⋅ft) of torque from 1,300-4,500 rpm for the AWD variant",
    createdAt: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
},
{
    id: '4',
    brand: 'BMW',
    model: '7 Series',
    licenseplate: 'TX 8948',
    image_name: '/images/bmw-7.jpg',
    state: 'Texas',
    zipcode: '75080',
    texta: "The BMW 7 Series is a full-size luxury sedan manufactured and marketed by the German automaker BMW since 1977. It is the successor to the BMW E3 'New Six' sedan and is currently in its sixth generation.The 7 Series is BMW's flagship car and is only available in a sedan bodystyle (including long wheelbase and limousine models). It traditionally introduces technologies and exterior design themes before other models in BMW's lineup.",
    createdAt: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
},
{
    id: '5',
    brand: 'BMW',
    model: 'M4 COUPE',
    licenseplate: 'NY 7920',
    image_name: '/images/bmw-m4-coupe.jpg',
    state: 'Newyork',
    zipcode: '14261',
    texta: "The BMW M4 is a high-performance version of the BMW 4 Series coupes and convertibles developed by BMW's motorsport division, BMW M, and marketed since 2014.As part of the renumbering that splits the 3 Series coupé and convertible models into the 4 Series (to further differentiate these from the 3 Series), the M4 replaced the BMW M3 coupé and convertible models.",
    createdAt: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
},
{
    id: '6',
    brand: 'BMW',
    model: 'X7',
    licenseplate: 'FL 1234',
    image_name: '/images/bmw-x7.jpg',
    state: 'Florida',
    zipcode: '33620',
    texta: "The BMW X7 is a full-sized luxury sport utility vehicle manufactured by BMW. It is BMW's largest and most expensive SUV in its line-up.The X7 was first announced by BMW in March 2014. It was officially unveiled on October 17, 2018, with pre-orders being taken online",
    createdAt: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
},

];


exports.find = function(){
    return trades;
}

exports.findByID = function(id){
    return trades.find(trade=>trade.id===id);
}

exports.save = function(trade){
    trade.id = uuidv4();
    trade.createdAt = DateTime.now().toLocaleString(DateTime.DATETIME_SHORT);
    trades.push(trade);
}

exports.updateByID = function(id, newTrade){
    trade = trades.find(trade=>trade.id===id);
    if(trade){
        trade.brand = newTrade.brand;
        trade.model = newTrade.model;
        trade.licenseplate =newTrade.licenseplate;
        trade.state = newTrade.state;
        trade.zipcode = newTrade.zipcode;
        trade.texta = newTrade.texta;
        console.log(trade.image_name);
        return true;
    }
    else{
        return false;
    }

}

exports.deleteByID = function(id){
    let index = trades.findIndex(trade=>trade.id===id);
    if(index === -1)
    {
        
        return false;
    }
    else{
        trades.splice(index,1);
        return true;
        
    }
}

*/