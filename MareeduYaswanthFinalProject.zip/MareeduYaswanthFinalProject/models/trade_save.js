const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const saveSchema = new Schema({
    brand: { type: String, required: [true, 'brand is required'] },
    model: { type: String, required: [true, 'model is required'] },
  SavedBy: {type: Schema.Types.ObjectId, ref:'User'},
  Status: { type: String },
});

const saveItem = mongoose.model("save", saveSchema);

module.exports = saveItem;
