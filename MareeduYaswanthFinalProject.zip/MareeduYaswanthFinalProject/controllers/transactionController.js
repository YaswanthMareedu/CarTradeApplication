const model = require("../models/trade");
const transactionModel = require("../models/interaction");
const watchModel = require("../models/favourites");

exports.createTrade = (req, res, next) => {
  model
    .findById(req.params.idt)
    .then((result) => {
      let transaction = new transactionModel({
        giverId: req.session.user,
        giveItem: req.params.idg,
        takerId: result.author,
        takeItem: req.params.idt,
        status: "pending",
      });
      transaction
        .save()
        .then((transaction) => {
          model
            .findById(req.params.idg)
            .then((trade) => {
              trade.status = "tradePosted";
              trade
                .save()
                .then()
                .catch((err) => next(err));
            })
            .catch((err) => next(err));
          model
            .findById(req.params.idt)
            .then((trade) => {
              trade.status = "tradePosted";
              trade
                .save()
                .then()
                .catch((err) => next(err));
            })
            .catch((err) => next(err));
          req.flash("success", "Posted Trade.");
          res.redirect("/users/profile");
        })
        .catch((err) => {
          next(err);
        });
    })
    .catch((err) => next(err));
};

exports.cancelTrade = (req, res, next) => {
  let transactionId = req.params.transId;
  transactionModel
    .findById(transactionId)
    .then((transaction) => {
      transaction.status = "cancelled";
      transaction
        .save()
        .then((transaction) => {
          model
            .findById(transaction.giveItem)
            .then((trade) => {
              trade.status = "available";
              trade
                .save()
                .then()
                .catch((err) => next(err));
            })
            .catch((err) => next(err));
          model
            .findById(transaction.takeItem)
            .then((trade) => {
              trade.status = "available";
              trade
                .save()
                .then()
                .catch((err) => next(err));
            })
            .catch((err) => next(err));
          req.flash("success", "Cancelled a Trade");
          res.redirect("/users/profile");
        })
        .catch((err) => next(err));
    })
    .catch((err) => next(err));
};

exports.acceptTrade = (req, res, next) => {
    let id = req.params.transId;
    transactionModel
      .findById(id)
      .then((transaction) => {
        transaction.status = 'accepted';
        transaction.save()
        .then(transaction => {
            Promise.all([
                model.findById(transaction.giveItem),
                model.findById(transaction.takeItem),
              ])
                .then((results) => {
                  const [user1Trade, user2Trade] = results;
                  user1Trade.status = 'available';
                  user2Trade.status = 'available';
                  let user1 = user1Trade.author;
                  user1Trade.author = user2Trade.author;
                  user2Trade.author = user1;
                  Promise.all([user1Trade.save(), user2Trade.save()])
                    .then((results) => {
                      req.flash("success", "Trade accepted.");
                      res.redirect("/users/profile");
                    })
                    .catch((err) => next(err));
                })
                .catch((err) => next(err));
        })
        .catch((err) => next(err));
      })
      .catch((err) => next(err));
};

exports.rejectTrade = (req, res, next) => {
    let id = req.params.transId;
    transactionModel
      .findById(id)
      .then((transaction) => {
        transaction.status = 'rejected';
        transaction.save()
        .then(transaction => {
            Promise.all([
                model.findById(transaction.giveItem),
                model.findById(transaction.takeItem),
              ])
                .then((results) => {
                  const [giveTrade, takeTrade] = results;
                  giveTrade.status = 'available';
                  takeTrade.status = 'available';
                  Promise.all([giveTrade.save(), takeTrade.save()])
                    .then((results) => {
                      req.flash("error", "Trade rejected.");
                      res.redirect("/users/profile");
                    })
                    .catch((err) => next(err));
                })
                .catch((err) => next(err));
        })
        .catch((err) => next(err));
      })
      .catch((err) => next(err));
  };

exports.favourites = (req,res,next) => {
      let id = req.params.tradeId;
      let watchlist = new watchModel({
        userId: req.session.user,
        itemId: id
      });
      watchModel.findOne({
        userId: req.session.user,
        itemId: id
      })
      .then(existItem => {
          if(existItem == null){
            watchlist.save()
            .then(watch => {
            })
            .catch(err => next(err));
          }
          res.redirect("/users/profile");
      })
      .catch(err => next(err));

      
  } 

  exports.deleteFavourite = (req, res, next) => {
    watchModel.findByIdAndDelete(req.params.watchId)
    .then( data => {
      res.redirect("/users/profile");
    }
    ).catch(err=> next(err));
  };