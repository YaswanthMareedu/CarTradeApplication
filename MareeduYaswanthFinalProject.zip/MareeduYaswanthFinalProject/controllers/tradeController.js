
const model = require('../models/trade');
const transactionModel = require("../models/interaction");
const { promise } = require("bcrypt/promises");

function uniqueBy(arr, prop) {
    return arr.reduce((a, d) => {
      if (!a.includes(d[prop])) {
        a.push(d[prop]);
      }
      return a;
    }, []);
  }

exports.index = (req, res)=>{
    model.find()
    .then(stories => res.render('./trade/index', {stories}))
    .catch(err => next(err));
};


exports.new = (req, res)=>{
    res.render('./trade/newTrade');
};

exports.create = (req, res, next) => {
    //res.send('Created a new story');
    let story = new model(req.body); //create a new story document
    story.author = req.session.user;
    story.save() //insert the document to the database
        .then(story =>{
            req.flash('success', 'Trade has been created successfully');
            res.redirect('/trades');
        })
        .catch(err => {
            if (err.name === 'ValidationError') {
                req.flash('error', err.message);
                return res.redirect('/back');
            }
            next(err);
        });

};

exports.show = (req, res, next) => {
    let id = req.params.id;
    //an objectId is a 24-bit Hex string 

    let user = req.session.user;
    Promise.all([model.findById(id), model.find({ author : user })])
        .then((results) => {
            const [story, stories] = results;
            if (story) {
                return res.render('./trade/show', { story, stories });
            }
            else {
                let err = new Error('Cannot find a story with id ' + id);
                err.status = 404;
                next(err);
            }
        })
        .catch(err => next(err));
};

exports.edit = (req, res, next) => {
    let id = req.params.id;
    model.findById(id)
    .then(story=>{
        return res.render('./trade/edit', {story});
    })
    .catch(err=>next(err));
};

exports.update = (req, res, next) => {
    let story = req.body;
    let id = req.params.id;

    model.findByIdAndUpdate(id, story, { useFindAndModify: false, runValidators: true })
        .then(story => {
                res.redirect('/trades/' + id);
            })
            .catch(err=> {
                if(err.name === 'ValidationError') {
                    req.flash('error', err.message);
                    return res.redirect('/back');
                }
                next(err);
            });
        };
            


exports.delete = (req, res, next) => {
    let id = req.params.id;

    model.findByIdAndDelete(id, {useFindAndModify: false})
        .then(story => {
                res.redirect('/trades');
            })
            .catch(err=>next(err));
};


exports.save = (req, res, next) => {
    console.log("in save");
    let id = req.params.id;
    model
      .findByIdAndUpdate(
        id,
        { Saved: true },
        {
            useFindAndModify: false,
            runValidators: true,
        }
      )
      .then((story) => {
        let brand = story.brand;
        let newSaveItem = new save_model({
          brand: story.brand,
          model: story.model,
          Status: story.Status,
        });
        newSaveItem.SavedBy = req.session.user;
        save_model
          .findOne({ brand: brand })
          .then((story) => {
            if (!story) {
              newSaveItem
                .save()
                .then((newSaveItem) => {
                  req.flash("success", "Item Added to Wishlist");
                  res.redirect("/nav/profile");
                })
                .catch((err) => {
                  if (err.name === "ValidationError") {
                    err.status = 400;
                  }
                  next(err);
                });
            } else {
              req.flash("error", "item already saved");
              res.redirect("/nav/save");
            }
          })
          .catch((err) => {
            next(err);
          });
      })
      .catch((err) => {
        next(err);
      });
  };
  

