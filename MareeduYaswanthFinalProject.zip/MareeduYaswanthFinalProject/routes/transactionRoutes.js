const express = require("express");
const router = express.Router();
const controller = require("../controllers/transactionController");
const{authenticated, isAuthor} = require('../middlewares/auth');
const{isValidId,checkvalidtransaction} = require('../middlewares/validator');

router.post("/:transId",controller.cancelTrade);

router.post("/:transId/accept", controller.acceptTrade);

router.post("/:transId/reject", controller.rejectTrade);

router.post("/:tradeId/watchlist", controller.favourites);

router.post("/:idg/:idt", checkvalidtransaction, authenticated, controller.createTrade);

router.delete("/deleteWatch/:watchId", controller.deleteFavourite);

module.exports = router;