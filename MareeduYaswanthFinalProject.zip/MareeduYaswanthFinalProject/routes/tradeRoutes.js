const express = require('express');
const controller = require('../controllers/tradeController');
const {authenticated, isAuthor} = require('../middlewares/auth');
const{validateId, validateStory, validateResult} = require('../middlewares/validator');

const router = express.Router();


router.get('/',controller.index);

router.get('/new', authenticated, controller.new);

router.post('/', authenticated,validateStory, validateResult, controller.create);

router.get('/:id', validateId, controller.show);

router.get('/:id/edit', validateId, authenticated, isAuthor, controller.edit);

router.put('/:id', validateId, authenticated, isAuthor,validateStory, validateResult, controller.update);

router.delete('/:id', validateId, authenticated, isAuthor, controller.delete);

module.exports = router;